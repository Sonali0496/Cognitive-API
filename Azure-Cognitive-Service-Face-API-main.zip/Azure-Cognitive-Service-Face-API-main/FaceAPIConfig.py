
subscription_key = "Enter Your Key here"
face_api_url = 'https://face2817.cognitiveservices.azure.com/face/v1.0/detect'


def config():
    print("Call Config")
    return subscription_key, face_api_url
