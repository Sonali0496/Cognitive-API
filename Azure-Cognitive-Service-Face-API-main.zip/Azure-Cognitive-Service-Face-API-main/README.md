Cognitive Services brings AI to every developer without having expertise in machine-learning. All it need is AI API call to access the ability to see, hear, speak, search, understand and accelerate decision making in applications.

- Create a new resource in Microsoft Azure for Face API
- Copy Subscription and endpoint URL's from Azure
- Create a configuration file for subscription keys-One Time Only(FaceAPI_conifg.py)
- Create Headers and params, then send a request for face recognition(AzureFaceAPI_Basic.py)
